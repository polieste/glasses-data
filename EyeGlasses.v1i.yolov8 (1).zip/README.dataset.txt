# EyeGlasses > 2024-06-13 1:00pm
https://universe.roboflow.com/yolov8glasses/eyeglasses-cd3iy

Provided by a Roboflow user
License: MIT

