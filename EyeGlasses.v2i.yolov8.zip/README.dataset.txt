# EyeGlasses > 2024-06-14 3:24am
https://universe.roboflow.com/yolov8glasses/eyeglasses-cd3iy

Provided by a Roboflow user
License: MIT

